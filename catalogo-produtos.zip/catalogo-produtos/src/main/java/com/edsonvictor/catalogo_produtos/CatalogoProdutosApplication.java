package com.edsonvictor.catalogo_produtos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoProdutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoProdutosApplication.class, args);
	}

}
