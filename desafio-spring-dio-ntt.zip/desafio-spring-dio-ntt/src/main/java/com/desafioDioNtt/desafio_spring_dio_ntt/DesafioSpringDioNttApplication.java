package com.desafioDioNtt.desafio_spring_dio_ntt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioSpringDioNttApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioSpringDioNttApplication.class, args);
	}

}
