package com.desafioDioNtt.desafio_spring_dio_ntt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioSpringDioNttApplicationTests {

	@Test
	void contextLoads() {
	}

}
