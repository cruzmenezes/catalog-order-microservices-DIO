package com.edsonvictor.simulador_pedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimuladorPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
